var product = 3

while product <= 100 {
    product *= 3
}

println(product)

