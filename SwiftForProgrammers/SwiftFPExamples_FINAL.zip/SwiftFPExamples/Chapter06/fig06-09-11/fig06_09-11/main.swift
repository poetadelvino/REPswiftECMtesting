// fig06-09-11: main.swift
// Card shuffling and dealing.

// format a String left aligned in a field
func formatString(var string: String, fieldWidth: Int) -> String {
    let spaces: Int = fieldWidth - countElements(string)
    let padding = String(count: spaces, repeatedValue: Character(" "))
    string += padding
    return string
}

var myDeckOfCards = DeckOfCards()
myDeckOfCards.shuffle() // place Cards in random order

// deal all 52 Cards with for...in
for i in 1 ... myDeckOfCards.numberOfCards {
    if let card = myDeckOfCards.dealCard() { // deal and unwrap Card
        print(formatString(card.description, 19)) // display Card

        if (i % 4 == 0) { // move to next line after every fourth card
            println()
        }
    }
}

println()
myDeckOfCards.shuffle()

// deal all 52 Cards with while
var i = 0

while let card = myDeckOfCards.dealCard() { // deal and unwrap Card
    ++i
    print(formatString(card.description, 19)) // display Card
    
    if (i % 4 == 0) { // move to next line after every fourth card
        println()
    }
}

/*************************************************************************
* (C) Copyright 1992-2015 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/
